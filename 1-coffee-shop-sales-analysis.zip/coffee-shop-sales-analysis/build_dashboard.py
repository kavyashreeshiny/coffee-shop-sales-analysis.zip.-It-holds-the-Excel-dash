"""Build coffee_shop_dashboard.xlsx from coffee_sales.csv.
Sheets: Dashboard (KPIs, summary tables, charts) and Data (Excel Table, ready for slicers)."""
import csv
from datetime import date
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.table import Table, TableStyleInfo

F = "Arial"
NAVY = "1F3A5F"
rows = list(csv.reader(open("coffee_sales.csv")))
hdr, data = rows[0], rows[1:]
N = len(data)
last = N + 1

wb = Workbook()
db = wb.active; db.title = "Dashboard"
ds = wb.create_sheet("Data")

ds.append(hdr + ["Revenue"])
for i, r in enumerate(data, start=2):
    y, m, d = map(int, r[1].split("-"))
    ds.append([r[0], date(y, m, d), r[2], r[3], r[4], int(r[5]), float(r[6]), r[7], r[8], f"=F{i}*G{i}"])
    ds.cell(i, 2).number_format = "dd-mmm-yyyy"
    ds.cell(i, 7).number_format = "#,##0"
    ds.cell(i, 10).number_format = "#,##0"
for c in ds[1]:
    c.font = Font(name=F, bold=True, color="FFFFFF")
for row in ds.iter_rows(min_row=2):
    for c in row: c.font = Font(name=F, size=10)
for col, w in zip("ABCDEFGHIJ", [11, 13, 14, 11, 18, 9, 11, 15, 14, 11]):
    ds.column_dimensions[col].width = w
t = Table(displayName="SalesData", ref=f"A1:J{last}")
t.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
ds.add_table(t)
ds.freeze_panes = "A2"

def rng(col): return f"Data!${col}$2:${col}${last}"
REV, QTY, ORD, CAT, STORE, PROD, DATE_, PAY, CUST = rng("J"), rng("F"), rng("A"), rng("D"), rng("C"), rng("E"), rng("B"), rng("H"), rng("I")

db.sheet_view.showGridLines = False
db["A1"] = "Coffee Shop Sales Dashboard - 2025"; db["A1"].font = Font(name=F, size=18, bold=True, color=NAVY)
db["A2"] = "Synthetic data (1,200 orders, 4 stores). All figures are live formulas on the Data sheet."; db["A2"].font = Font(name=F, size=9, italic=True, color="666666")
thin = Side(style="thin", color="BBBBBB")
box = Border(left=thin, right=thin, top=thin, bottom=thin)
fill = PatternFill("solid", fgColor=NAVY)

# KPI tiles: Revenue A5, Orders C5, Units E5, AOV G5
kpis = [("Total Revenue (INR)", f"=SUM({REV})", "#,##0"),
        ("Total Orders", f"=COUNTA({ORD})", "#,##0"),
        ("Units Sold", f"=SUM({QTY})", "#,##0"),
        ("Avg Order Value (INR)", "=A5/C5", "#,##0.00")]
for j, (label, f, fmt) in enumerate(kpis):
    col = 1 + j * 2
    l = db.cell(4, col, label); l.font = Font(name=F, size=9, bold=True, color="FFFFFF"); l.fill = fill
    l.alignment = Alignment(horizontal="center")
    db.merge_cells(start_row=4, start_column=col, end_row=4, end_column=col + 1)
    v = db.cell(5, col, f); v.number_format = fmt; v.font = Font(name=F, size=16, bold=True, color=NAVY)
    v.alignment = Alignment(horizontal="center")
    db.merge_cells(start_row=5, start_column=col, end_row=5, end_column=col + 1)

def head(r, headers):
    for j, h in enumerate(headers):
        c = db.cell(r, 1 + j, h); c.font = Font(name=F, bold=True, color="FFFFFF", size=10); c.fill = fill; c.border = box

def table(r0, title, headers, labels, formulas):
    db.cell(r0, 1, title).font = Font(name=F, bold=True, size=11, color=NAVY)
    head(r0 + 1, headers)
    for i, lab in enumerate(labels):
        r = r0 + 2 + i
        a = db.cell(r, 1, lab); a.font = Font(name=F, size=10); a.border = box
        for j, f in enumerate(formulas):
            c = db.cell(r, 2 + j, f.format(r=r)); c.font = Font(name=F, size=10); c.border = box
            c.number_format = "#,##0"
    return r0 + 2, r0 + 1 + len(labels)

cats = ["Coffee", "Tea", "Bakery", "Snacks"]
stores = ["Indiranagar", "Koramangala", "Whitefield", "Jayanagar"]
prods = sorted({r[4] for r in data})
months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

c0, c1 = table(8, "Revenue by Category", ["Category", "Revenue", "Orders"], cats,
               [f"=SUMIFS({REV},{CAT},$A{{r}})", f"=COUNTIFS({CAT},$A{{r}})"])
s0, s1 = table(16, "Revenue by Store", ["Store", "Revenue", "Orders"], stores,
               [f"=SUMIFS({REV},{STORE},$A{{r}})", f"=COUNTIFS({STORE},$A{{r}})"])
m_r0 = 24
db.cell(m_r0, 1, "Monthly Revenue").font = Font(name=F, bold=True, size=11, color=NAVY)
head(m_r0 + 1, ["Month", "Revenue", "Orders"])
for i, name in enumerate(months):
    n = i + 1; r = m_r0 + 2 + i
    db.cell(r, 1, name).font = Font(name=F, size=10); db.cell(r, 1).border = box
    s = f"DATE(2025,{n},1)"; e = f"DATE(2025,{n+1},1)" if n < 12 else "DATE(2026,1,1)"
    db.cell(r, 2, f'=SUMIFS({REV},{DATE_},">="&{s},{DATE_},"<"&{e})')
    db.cell(r, 3, f'=COUNTIFS({DATE_},">="&{s},{DATE_},"<"&{e})')
    for k in (2, 3):
        db.cell(r, k).number_format = "#,##0"; db.cell(r, k).font = Font(name=F, size=10); db.cell(r, k).border = box
m0, m1 = m_r0 + 2, m_r0 + 13
p0, p1 = table(m_r0 + 15, "Revenue by Product", ["Product", "Revenue", "Units"], prods,
               [f"=SUMIFS({REV},{PROD},$A{{r}})", f"=SUMIFS({QTY},{PROD},$A{{r}})"])
pay0, pay1 = table(p1 + 2, "Payment Method Split", ["Method", "Revenue", "Orders"], ["UPI", "Card", "Cash"],
                   [f"=SUMIFS({REV},{PAY},$A{{r}})", f"=COUNTIFS({PAY},$A{{r}})"])
db.column_dimensions["A"].width = 20
for col in "BCDEFGH": db.column_dimensions[col].width = 15

def place(ch, anchor, w, h):
    ch.width, ch.height = w, h; db.add_chart(ch, anchor)

b = BarChart(); b.type = "col"; b.title = "Revenue by Category"; b.legend = None
b.add_data(Reference(db, min_col=2, min_row=c0 - 1, max_row=c1), titles_from_data=True)
b.set_categories(Reference(db, min_col=1, min_row=c0, max_row=c1)); place(b, "E8", 12, 7)
b2 = BarChart(); b2.type = "bar"; b2.title = "Revenue by Store"; b2.legend = None
b2.add_data(Reference(db, min_col=2, min_row=s0 - 1, max_row=s1), titles_from_data=True)
b2.set_categories(Reference(db, min_col=1, min_row=s0, max_row=s1)); place(b2, "E22", 12, 7)
ln = LineChart(); ln.title = "Monthly Revenue Trend"; ln.legend = None
ln.add_data(Reference(db, min_col=2, min_row=m0 - 1, max_row=m1), titles_from_data=True)
ln.set_categories(Reference(db, min_col=1, min_row=m0, max_row=m1)); place(ln, "E36", 12, 7)
pie = PieChart(); pie.title = "Payment Method Split"
pie.add_data(Reference(db, min_col=2, min_row=pay0 - 1, max_row=pay1), titles_from_data=True)
pie.set_categories(Reference(db, min_col=1, min_row=pay0, max_row=pay1)); place(pie, "E50", 12, 7)

wb.save("coffee_shop_dashboard.xlsx")
print("saved")
