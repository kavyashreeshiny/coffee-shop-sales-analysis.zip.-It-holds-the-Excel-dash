"""Generate a synthetic coffee-shop sales dataset (1,200 orders, 2025).
All data is randomly generated for portfolio/demo purposes - it is not real sales data."""
import csv, random
from datetime import date, timedelta

random.seed(42)
MENU = {
    "Coffee":  [("Espresso", 120), ("Americano", 140), ("Cappuccino", 170), ("Latte", 180), ("Mocha", 200)],
    "Tea":     [("Masala Chai", 90), ("Green Tea", 110), ("Iced Lemon Tea", 130)],
    "Bakery":  [("Croissant", 120), ("Blueberry Muffin", 110), ("Brownie", 130)],
    "Snacks":  [("Veg Sandwich", 160), ("Paneer Wrap", 190), ("Nachos", 150)],
}
CAT_WEIGHT = {"Coffee": 0.5, "Tea": 0.15, "Bakery": 0.2, "Snacks": 0.15}
STORES = ["Indiranagar", "Koramangala", "Whitefield", "Jayanagar"]
PAY = ["UPI", "Card", "Cash"]
CUST = ["Member", "Walk-in"]

rows = []
start = date(2025, 1, 1)
for i in range(1, 1201):
    d = start + timedelta(days=random.randint(0, 364))
    cat = random.choices(list(CAT_WEIGHT), weights=CAT_WEIGHT.values())[0]
    prod, price = random.choice(MENU[cat])
    rows.append([f"ORD{i:05d}", d.isoformat(), random.choice(STORES), cat, prod,
                 random.choices([1, 2, 3, 4], weights=[55, 28, 12, 5])[0], price,
                 random.choices(PAY, weights=[50, 30, 20])[0],
                 random.choices(CUST, weights=[35, 65])[0]])
rows.sort(key=lambda r: r[1])
with open("coffee_sales.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["Order ID", "Date", "Store", "Category", "Product", "Quantity", "Unit Price", "Payment Method", "Customer Type"])
    w.writerows(rows)
print(len(rows), "rows written")
