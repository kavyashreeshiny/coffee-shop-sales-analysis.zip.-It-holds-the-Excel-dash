# Coffee Shop Sales Analysis (Excel)

Interactive KPI dashboard built on 1,200 synthetic coffee-shop orders (2025, 4 stores).

**Tools:** Excel, Python (data generation only)

## What's inside
| File | Purpose |
|---|---|
| `coffee_shop_dashboard.xlsx` | Dashboard sheet (KPIs, summary tables, 4 charts) + Data sheet (Excel Table) |
| `coffee_sales.csv` | Raw dataset |
| `generate_data.py` | Generates the synthetic dataset (seeded, reproducible) |
| `build_dashboard.py` | Rebuilds the workbook from the CSV |

## Dashboard
- KPIs: total revenue, orders, units sold, average order value
- Revenue by category, store, month, product and payment method (SUMIFS / COUNTIFS)
- Charts: category, store, monthly trend, payment split

## Add slicers (about 2 minutes, in Excel)
1. Open the **Data** sheet and click any cell in the table (`SalesData`).
2. **Table Design > Insert Slicer** and tick *Store*, *Category*, *Customer Type*.
3. Optional: **Insert > PivotTable** from `SalesData` for a drag-and-drop pivot view,
   then connect the slicers via **Slicer > Report Connections**.

## Data note
All data is randomly generated for demonstration. It is not real sales data.
